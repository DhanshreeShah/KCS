﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enums
{
    enum No 
    {
        One=1,
        Two,
        Three,
        Twenty=20,
        Twentyone,
        Twentytwo,
        Twentythree,
        Twentyfour,
        Twentyfive,
        Twentysix,
        Twentyseven,
        Twentyeight,
        Twentynine,
            
    }
    class Program
    {
        public void DemoExceptional()
        {
            try
            {
                int a = 100;
                Console.WriteLine("Value of a is:"+a);
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
            finally
            {
                Console.WriteLine("Finally");
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Convert.ToInt32(No.Twentyone) + 11);

            Console.ReadKey();
        }
    }
}
